# BNB Treasure Hunt

A tiny playable prototype:
- `index.html` is the game.
- `TreasureToken.sol` is an educational reward-token skeleton.

## Run
Open `index.html` in a browser.

The game is intentionally off-chain: clicks do not cost gas.

## Next blockchain step
Deploy the token to BNB Chain Testnet first, then replace the simple owner-only
reward function with signed reward claims (EIP-712-style authorization + nonces)
and server-side score verification before considering mainnet.
