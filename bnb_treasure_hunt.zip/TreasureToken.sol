// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/*
 * Educational reward-token skeleton.
 * This is NOT production-ready: reward authorization should use
 * signatures/nonces and strong anti-cheat controls before mainnet use.
 */
contract TreasureToken {
    string public constant name = "Treasure Token";
    string public constant symbol = "TREAS";
    uint8 public constant decimals = 18;

    uint256 public totalSupply;
    address public owner;
    uint256 public constant MAX_REWARD = 1000 ether;

    mapping(address => uint256) public balanceOf;

    constructor() {
        owner = msg.sender;
    }

    function mintReward(address recipient, uint256 amount) external {
        require(msg.sender == owner, "Only game authority");
        require(amount <= MAX_REWARD, "Reward too large");
        balanceOf[recipient] += amount;
        totalSupply += amount;
    }
}
